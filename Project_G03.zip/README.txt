before starting to play read the rules menu by pressing R
or use the mouse to click the button.

everthing is kept inside the sources file it's to separte the documentation
from the code since the code is spit up in different files and the inc files are
also inside their separate folder.

Note: game.exe will be created in parent folder, wmake file inside sources folder.
Project made by:
                Rodolfo Alberto Perez Tobar
                0555239
                bachelor Computerwetenschappen